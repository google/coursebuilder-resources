#!/usr/bin/env python
"""Sample user config for test."""

# pylint: disable=g-bad-name
mapreduce_SHARD_MAX_ATTEMPTS = 5
mapreduce_QUEUE_NAME = "foo"
mapreduce_BASE_PATH = "/my-mapreduce"
