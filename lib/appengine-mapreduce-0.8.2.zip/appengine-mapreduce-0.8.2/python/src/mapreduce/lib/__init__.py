#!/usr/bin/env python
"""Various libraries implementing mapreduce.api."""
