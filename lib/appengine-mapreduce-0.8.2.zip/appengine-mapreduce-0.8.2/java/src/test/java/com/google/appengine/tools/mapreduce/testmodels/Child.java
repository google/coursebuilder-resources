package com.google.appengine.tools.mapreduce.testmodels;


public class Child {
  public String fullName;
  public int age;
  /**
   * @param fullName
   * @param age
   */
  public Child(String fullName, int age) {
    this.fullName = fullName;
    this.age = age;
  }
  
  
}
