package com.google.appengine.demos.mapreduce.bigqueryload;

public class SampleNestedRecord {
  int col11;
  String col12;
  /**
   * @param col11
   * @param col12
   */
  public SampleNestedRecord(int col11, String col12) {
    this.col11 = col11;
    this.col12 = col12;
  }
  
}
