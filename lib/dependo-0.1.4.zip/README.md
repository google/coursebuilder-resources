Modification of dependo library by Kenneth Auchenberg,
https://github.com/auchenberg/dependo.

Course Builder modifications are in directory cb/. Original source code is in directory orig/.
