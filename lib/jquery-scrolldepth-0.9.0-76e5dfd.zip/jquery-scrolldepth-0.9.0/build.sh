#!/bin/bash
uglifyjs jquery.scrolldepth.js -c -m --comments -o jquery.scrolldepth.min.js