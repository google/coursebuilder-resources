# Contributing to Riveted

Contributions are welcome! There are just a few requested guidelines:

* Please create a feature branch for your changes
* Don't worry about updating the version, changelog, or minified version (I can take care of that)
* Please respect the original syntax/formatting stuff

Thanks!
