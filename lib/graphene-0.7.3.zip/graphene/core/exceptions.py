class SkipField(Exception):
    pass
