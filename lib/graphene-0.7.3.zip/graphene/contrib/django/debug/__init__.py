from .plugin import DjangoDebugPlugin
from .types import DjangoDebug

__all__ = ['DjangoDebugPlugin', 'DjangoDebug']
